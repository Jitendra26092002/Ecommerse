from django.shortcuts import render
from shop_app.models import Product, Category
# Create your views here.

def master(request):
    category=Category.objects.all()
    # sub_category=Sub_Category.objects.all()
    product=Product.objects.all()
    context={
         "category":category,
        # "sub_category":sub_category,
        "product":product,
        
    }
    return render(request,"master.html",context)

    
   

   
    
   
    